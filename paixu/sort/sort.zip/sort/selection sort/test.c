#include<stdio.h>
#include<time.h>
#include"heap_sort.c"
#include"simple_selection_sort.c"

void main()
{
	int i;
	int a[7]={0,3,5,8,9,1,2};//������a[0]
    simpleSelectionSort1(a,6);
	simpleSelectionSort1(a,6);
	heapSort(a,6);
	for(i=1;i<=6;i++)
		printf("%-4d",a[i]);
	printf("\n");
}
