#include<stdio.h>

//ð������
void bubbleSort(int *a,int n)
{
	int i,j;
	for(i=1;i<n;i++)
		for(j=1;j<n-i+1;j++){
			if(a[j+1]<a[j]){
				a[j]=a[j]+a[j+1];
				a[j+1]=a[j]-a[j+1];
				a[j]=a[j]-a[j+1];
			}
		}
}


void main()
{
	int i;
	int a[7]={0,3,5,8,9,1,2};//������a[0]
	bubbleSort(a,6);
	for(i=1;i<=6;i++)
		printf("%-4d",a[i]);
	printf("\n");
}
